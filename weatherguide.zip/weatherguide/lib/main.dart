import 'package:flutter/material.dart';
import 'WeatherSelection.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Weather Guide',
      theme: ThemeData(
        primarySwatch: Colors.blue,
        scaffoldBackgroundColor: Colors.black, // Set the default background color to black
        textTheme: const TextTheme(
          bodyLarge: TextStyle(color: Colors.white), // Set body text color to white
          bodyMedium: TextStyle(color: Colors.white), // Set medium text color to white
          bodySmall: TextStyle(color: Colors.white), // Set small text color to white
          headlineLarge: TextStyle(color: Colors.white), // Set large headline text color to white
          titleLarge: TextStyle(color: Colors.white), // Set title text color to white
        ),
      ),
      home: const WeatherSelectionScreen(),
    );
  }
}





