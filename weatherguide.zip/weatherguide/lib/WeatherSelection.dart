import 'package:flutter/material.dart';
import 'WeatherDetails.dart';

class WeatherSelectionScreen extends StatefulWidget {
  const WeatherSelectionScreen({Key? key}) : super(key: key);

  @override
  State<WeatherSelectionScreen> createState() => _WeatherSelectionScreenState();
}

class _WeatherSelectionScreenState extends State<WeatherSelectionScreen> {
  final TextEditingController _temperatureController = TextEditingController();
  String _convertedTemperature = '';
  String _conversionType = 'C to F';

  void _convertTemperature() {
    try {
      double temp = double.parse(_temperatureController.text);
      if (_conversionType == 'C to F') {
        temp = (temp * 9 / 5) + 32;
        setState(() {
          _convertedTemperature = '${temp.toStringAsFixed(2)} °F';
        });
      } else {
        temp = (temp - 32) * 5 / 9;
        setState(() {
          _convertedTemperature = '${temp.toStringAsFixed(2)} °C';
        });
      }
    } catch (e) {
      setState(() {
        _convertedTemperature = 'Invalid input';
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Weather Guide'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            const Text(
              'Select Weather Condition:',
              style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
              textAlign: TextAlign.center,
            ),
            const SizedBox(height: 20),
            _buildWeatherButton(context, 'Rainy', Icons.umbrella, Colors.grey),
            const SizedBox(height: 10),
            _buildWeatherButton(context, 'Sunny', Icons.wb_sunny, Colors.orange),
            const SizedBox(height: 10),
            _buildWeatherButton(context, 'Cold', Icons.ac_unit, Colors.cyan),
            const SizedBox(height: 30),
            ElevatedButton.icon(
              icon: const Icon(Icons.location_on),
              label: const Text('Get Weather by Location'),
              style: ElevatedButton.styleFrom(
                padding: const EdgeInsets.symmetric(vertical: 16),
                backgroundColor: Colors.green,
              ),
              onPressed: () {
                final temperature = _getHardcodedTemperature(); // Hardcoded value
                final weatherType = _determineWeatherByTemperature(temperature);

                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (context) => WeatherDetailsScreen(
                      weatherType: weatherType,
                      temperature: temperature,
                    ),
                  ),
                );
              },
            ),
            const SizedBox(height: 30),
            const Text(
              'Convert Temperature:',
              style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
              textAlign: TextAlign.center,
            ),
            const SizedBox(height: 10),
            TextField(
              controller: _temperatureController,
              keyboardType: TextInputType.number,
              decoration: const InputDecoration(
                border: OutlineInputBorder(),
                labelText: 'Enter Temperature',
              ),
            ),
            const SizedBox(height: 10),
            DropdownButton<String>(
              value: _conversionType,
              onChanged: (String? newValue) {
                setState(() {
                  _conversionType = newValue!;
                });
              },
              items: <String>['C to F', 'F to C']
                  .map<DropdownMenuItem<String>>((String value) {
                return DropdownMenuItem<String>(
                  value: value,
                  child: Text(value),
                );
              }).toList(),
            ),
            const SizedBox(height: 10),
            ElevatedButton(
              onPressed: _convertTemperature,
              child: const Text('Convert'),
            ),
            const SizedBox(height: 10),
            Text(
              _convertedTemperature,
              style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
              textAlign: TextAlign.center,
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildWeatherButton(
    BuildContext context,
    String weatherType,
    IconData icon,
    Color color,
  ) {
    return ElevatedButton.icon(
      icon: Icon(icon, color: Colors.white),
      label: Text(weatherType),
      style: ElevatedButton.styleFrom(
        padding: const EdgeInsets.symmetric(vertical: 16),
        backgroundColor: color,
      ),
      onPressed: () {
        int temperature;

        
        if (weatherType == 'Sunny') {
          temperature = 25;
        } else if (weatherType == 'Rainy') {
          temperature = 12; 
        } else {
          temperature = -5;
        }

        Navigator.push(
          context,
          MaterialPageRoute(
            builder: (context) => WeatherDetailsScreen(
              weatherType: weatherType,
              temperature: temperature,
            ),
          ),
        );
      },
    );
  }

  int _getHardcodedTemperature() {
    
    return 12; 
  }

  String _determineWeatherByTemperature(int temperature) {
    if (temperature > 15) {
      return 'Sunny';
    } else if (temperature >= 0) {
      return 'Rainy';
    } else {
      return 'Cold';
    }
  }
}


