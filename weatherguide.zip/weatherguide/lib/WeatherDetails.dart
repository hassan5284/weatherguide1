import 'package:flutter/material.dart';

class WeatherDetailsScreen extends StatelessWidget {
  final String weatherType;
  final int? temperature;

  const WeatherDetailsScreen({Key? key, required this.weatherType, this.temperature}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final recommendations = _getRecommendations(weatherType);

    return Scaffold(
      appBar: AppBar(
        title: Text('$weatherType Weather Tips'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Icon(
              recommendations['icon'] as IconData,
              size: 100,
              color: recommendations['color'] as Color,
            ),
            const SizedBox(height: 20),
            if (temperature != null)
              Text(
                'Current Temperature: $temperature°C',
                style: const TextStyle(fontSize: 16),
                textAlign: TextAlign.center,
              ),
            const SizedBox(height: 20),
            Text(
              recommendations['clothing'] as String,
              style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
              textAlign: TextAlign.center,
            ),
            const SizedBox(height: 10),
            Text(
              recommendations['activity'] as String,
              style: const TextStyle(fontSize: 16),
              textAlign: TextAlign.center,
            ),
            const SizedBox(height: 30),
            ElevatedButton(
              onPressed: () {
                Navigator.pop(context);
              },
              child: const Text('Back to Selection'),
            ),
          ],
        ),
      ),
    );
  }

  Map<String, dynamic> _getRecommendations(String weatherType) {
    switch (weatherType) {
      case 'Rainy':
        return {
          'icon': Icons.umbrella,
          'color': Colors.blue,
          'clothing': 'Layer up with a warm fleece jacket and waterproof boots.',
          'activity': 'Stay cozy with board games, reading a book, or watching movies indoors.',
        };
      case 'Sunny':
        return {
          'icon': Icons.wb_sunny,
          'color': Colors.orange,
          'clothing': 'Opt for comfortable shorts and a breathable t-shirt, complemented with a wide-brimmed hat.',
          'activity': 'Participate in fun outdoor events such as frisbee games or nature walks.',
        };
      case 'Cold':
        return {
          'icon': Icons.ac_unit,
          'color': Colors.cyan,
          'clothing': 'Wear a heavy jacket and warm boots.',
          'activity': 'Drink hot beverages and stay cozy indoors.',
        };
      default:
        return {
          'icon': Icons.error,
          'color': Colors.red,
          'clothing': 'No recommendations available.',
          'activity': 'Please select a valid weather type.',
        };
    }
  }
}

