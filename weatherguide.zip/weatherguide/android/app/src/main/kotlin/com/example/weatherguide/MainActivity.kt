package com.example.weatherguide

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
